//
//  ViewController.h
//  BlueToothDataTransfer
//
//  Created by 徐胜 on 2016/11/16.
//  Copyright © 2016年 exhitec. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ViewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>


@end


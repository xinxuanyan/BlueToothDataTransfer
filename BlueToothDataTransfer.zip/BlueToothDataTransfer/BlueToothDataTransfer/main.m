//
//  main.m
//  BlueToothDataTransfer
//
//  Created by 徐胜 on 2016/11/16.
//  Copyright © 2016年 exhitec. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
